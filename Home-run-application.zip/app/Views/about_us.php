<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Page</title>
</head>
<body>
    <h1>Welcome To About Page</h1>
    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ipsum cum tempora porro itaque, expedita quibusdam aliquid praesentium voluptas velit tenetur, delectus facilis facere sint sequi eius maxime sit animi architecto!</p>
    <h5>Created by: Home Run Team</h5>
</body>
</html>